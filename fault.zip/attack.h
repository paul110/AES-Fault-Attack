#ifndef __ATTACK_H
#define __ATTACK_H

#include  <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include  <signal.h>
#include  <unistd.h>
#include   <fcntl.h>

#include <openssl/aes.h>

#endif
